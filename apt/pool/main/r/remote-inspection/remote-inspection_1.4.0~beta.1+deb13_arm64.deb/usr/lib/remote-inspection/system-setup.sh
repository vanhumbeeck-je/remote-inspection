#!/usr/bin/env bash
#
# Remote Inspection: system integration for the node service - idempotent.
# Used by install.sh (installs from a source tree) and by the Debian package's postinst.
#
#   sudo bash system-setup.sh                  service user, WiFi/hotspot rules, LED, no power saving
#   sudo bash system-setup.sh --pin-wired      ...and pin wired links without DHCP to link-local
#                                              (changes NetworkManager profiles; first install only)
#
#   INSPECTION_WIFI_COUNTRY=NL                 WiFi country used when none is set (default BE)
set -euo pipefail

DATA_DIR=/var/lib/inspection
SVC_USER=inspection
WIFI_COUNTRY="${INSPECTION_WIFI_COUNTRY:-BE}"
HOTSPOT_ADDRESS=10.42.0.1      # must match HOTSPOT_ADDRESS in inspection_node/config.py

PIN_WIRED=0
for a in "$@"; do
  case "$a" in
    --pin-wired) PIN_WIRED=1 ;;
    -h|--help) sed -n '2,11p' "$0"; exit 0 ;;
  esac
done

log()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mWARNING:\033[0m %s\n' "$*" >&2; }

[ "$(id -u)" -eq 0 ] || { warn "run as root"; exit 1; }

# --- 1. service user -----------------------------------------------------------------------
if ! id -u "$SVC_USER" >/dev/null 2>&1; then
  log "Creating service user $SVC_USER"
  useradd --system --home-dir "$DATA_DIR" --shell /usr/sbin/nologin --user-group "$SVC_USER"
fi
for g in video audio render; do
  getent group "$g" >/dev/null 2>&1 && usermod -a -G "$g" "$SVC_USER" || true
done
mkdir -p "$DATA_DIR"
chown -R "$SVC_USER:$SVC_USER" "$DATA_DIR"
chmod 750 "$DATA_DIR"

# --- 2. plug-and-play IPv4 on links without a DHCP server (NetworkManager) -----------------
# A wired profile in "auto" mode on a link without DHCP has been seen (NetworkManager 1.52) failing
# and re-activating every ~30 s even with the link-local fallback enabled, which makes the Pi
# unreachable most of the time; on a Pi that never had a lease the fallback address does not even
# appear, so the wired link keeps no IPv4 at all. So: an active wired connection that has a cable,
# no DHCP lease and either a 169.254.x.x address or no IPv4 address at all is pinned to
# ipv4.method=link-local (stable, always reachable on the segment; internet stays on WiFi). DHCP is
# given 20 s to answer first. Connections that do get a lease are left alone, only the link-local
# fallback is switched on for them.
REAPPLY_CONN=""
if [ "$PIN_WIRED" -eq 1 ] && command -v nmcli >/dev/null 2>&1 && systemctl is-active NetworkManager >/dev/null 2>&1; then
  while IFS=: read -r cname ctype cdev; do
    [ "$ctype" = "802-3-ethernet" ] || continue
    method="$(nmcli -g ipv4.method connection show "$cname" 2>/dev/null || true)"
    [ "$method" = "auto" ] || continue
    [ -n "$cdev" ] || continue
    lease=""; ll=0; any4=0; carrier=0; waited=0
    while : ; do
      lease="$(nmcli -g DHCP4.OPTION device show "$cdev" 2>/dev/null | head -1 || true)"
      ll="$(ip -4 -o addr show dev "$cdev" 2>/dev/null | grep -c ' 169\.254\.' || true)"
      any4="$(ip -4 -o addr show dev "$cdev" 2>/dev/null | grep -c ' inet ' || true)"
      carrier="$(cat "/sys/class/net/$cdev/carrier" 2>/dev/null || echo 0)"
      # Decided as soon as there is a lease, an address of any kind, or no cable at all.
      if [ -n "$lease" ] || [ "${ll:-0}" -gt 0 ] || [ "${any4:-0}" -gt 0 ] || [ "$carrier" != "1" ]; then break; fi
      if [ "$waited" -ge 20 ]; then break; fi
      if [ "$waited" -eq 0 ]; then log "Waiting up to 20 s for a DHCP lease on $cdev…"; fi
      sleep 2; waited=$((waited + 2))
    done
    if [ -z "$lease" ] && [ "$carrier" = "1" ] && { [ "${ll:-0}" -gt 0 ] || [ "${any4:-0}" -eq 0 ]; }; then
      log "NetworkManager: no DHCP server on $cdev; pinning '$cname' to a stable link-local address"
      if nmcli connection modify "$cname" ipv4.method link-local ipv4.may-fail yes ipv4.dhcp-timeout 0 >/dev/null 2>&1; then
        REAPPLY_CONN="$cname"
      else
        warn "could not modify connection '$cname'"
      fi
    else
      llmode="$(nmcli -g ipv4.link-local connection show "$cname" 2>/dev/null || true)"
      if ! printf '%s' "$llmode" | grep -qEi 'fallback|enabled|^[24]\b'; then
        log "NetworkManager: enabling link-local (169.254.x.x) fallback on '$cname'"
        nmcli connection modify "$cname" ipv4.link-local fallback ipv4.dhcp-timeout 10 ipv4.may-fail yes \
          >/dev/null 2>&1 || warn "could not modify connection '$cname' (older NetworkManager?)"
      fi
    fi
  done < <(nmcli -t -f NAME,TYPE,DEVICE connection show --active 2>/dev/null || true)
fi

# --- 3. no power saving on the network interfaces -----------------------------------------
# WiFi power save (brcmfmac default) makes the WiFi link lossy; Energy-Efficient Ethernet on the
# Pi's PHY has been linked to stalls on the wired link. Both are switched off now and on every
# future link-up (NetworkManager dispatcher), so a streaming appliance never sleeps its links.
if command -v nmcli >/dev/null 2>&1 && systemctl is-active NetworkManager >/dev/null 2>&1; then
  mkdir -p /etc/NetworkManager/conf.d
  printf '[connection]\nwifi.powersave=2\n' > /etc/NetworkManager/conf.d/20-inspection-no-powersave.conf
  while IFS=: read -r cname ctype; do
    [ "$ctype" = "802-11-wireless" ] || continue
    nmcli connection modify "$cname" 802-11-wireless.powersave 2 >/dev/null 2>&1 || true
  done < <(nmcli -t -f NAME,TYPE connection show 2>/dev/null || true)
  nmcli general reload conf 2>/dev/null || true
fi
mkdir -p /etc/NetworkManager/dispatcher.d
cat > /etc/NetworkManager/dispatcher.d/90-inspection-no-powersave <<'EOF'
#!/bin/sh
# Remote Inspection: keep network links awake. Runs on every NetworkManager link event.
dev="$1"; action="$2"
[ "$action" = "up" ] || exit 0
case "$dev" in
  wl*|wlan*) command -v iw >/dev/null 2>&1 && iw dev "$dev" set power_save off 2>/dev/null ;;
  eth*|en*)  command -v ethtool >/dev/null 2>&1 && ethtool --set-eee "$dev" eee off 2>/dev/null ;;
esac
exit 0
EOF
chmod 755 /etc/NetworkManager/dispatcher.d/90-inspection-no-powersave
for dev in /sys/class/net/*; do
  dev="$(basename "$dev")"
  case "$dev" in
    wl*|wlan*) command -v iw >/dev/null 2>&1 && iw dev "$dev" set power_save off 2>/dev/null && log "WiFi power save off on $dev" ;;
    eth*|en*)  command -v ethtool >/dev/null 2>&1 && ethtool --set-eee "$dev" eee off 2>/dev/null && log "Energy-Efficient Ethernet off on $dev" ;;
  esac
done

# --- 4. WiFi: joining networks, the fallback hotspot, QR codes, the status LED ------------
# The service runs unprivileged; a polkit rule lets it (and only it) add WiFi profiles and run
# its hotspot through NetworkManager. On the hotspot, NetworkManager's dnsmasq answers every name
# with the Pi, which makes phones offer the dashboard as the network's sign-in page.
if command -v nmcli >/dev/null 2>&1; then
  log "WiFi integration (polkit rule, hotspot captive DNS)"
  mkdir -p /etc/polkit-1/rules.d /etc/NetworkManager/dnsmasq-shared.d
  cat > /etc/polkit-1/rules.d/50-inspection-network.rules <<'EOF'
// Remote Inspection: the node service (user "inspection") joins WiFi networks and runs its
// fallback hotspot through NetworkManager. Installed by system-setup.sh.
polkit.addRule(function(action, subject) {
    if (subject.user == "inspection" && [
            "org.freedesktop.NetworkManager.settings.modify.system",
            "org.freedesktop.NetworkManager.network-control",
            "org.freedesktop.NetworkManager.wifi.share.protected",
            "org.freedesktop.NetworkManager.wifi.share.open",
            "org.freedesktop.NetworkManager.enable-disable-wifi",
            "org.freedesktop.NetworkManager.wifi.scan"
        ].indexOf(action.id) >= 0) {
        return polkit.Result.YES;
    }
});
EOF
  chmod 644 /etc/polkit-1/rules.d/50-inspection-network.rules
  printf '# Remote Inspection: on the fallback hotspot every name resolves to the Pi (captive portal)\naddress=/#/%s\n' \
    "$HOTSPOT_ADDRESS" > /etc/NetworkManager/dnsmasq-shared.d/50-inspection-captive.conf
  command -v rfkill >/dev/null 2>&1 && rfkill unblock wifi >/dev/null 2>&1 || true
  if command -v raspi-config >/dev/null 2>&1 && [ -z "$(raspi-config nonint get_wifi_country 2>/dev/null || true)" ]; then
    log "WiFi country not set: setting it to $WIFI_COUNTRY (INSPECTION_WIFI_COUNTRY=XX overrides)"
    raspi-config nonint do_wifi_country "$WIFI_COUNTRY" >/dev/null 2>&1 || warn "could not set the WiFi country"
  fi
else
  warn "NetworkManager is not installed: WiFi setup, the hotspot and WiFi QR codes are not available"
fi
# The green ACT LED shows the network state (heartbeat = hotspot, blinking = joining).
cat > /etc/udev/rules.d/90-inspection-led.rules <<'EOF'
# Remote Inspection: the node service shows its network state on the green ACT LED
SUBSYSTEM=="leds", KERNEL=="ACT|led0", RUN+="/bin/chgrp inspection /sys%p/trigger /sys%p/brightness", RUN+="/bin/chmod g+w /sys%p/trigger /sys%p/brightness"
EOF
for led in /sys/class/leds/ACT /sys/class/leds/led0; do
  if [ -e "$led/trigger" ]; then
    chgrp "$SVC_USER" "$led/trigger" "$led/brightness" 2>/dev/null && chmod g+w "$led/trigger" "$led/brightness" 2>/dev/null || true
  fi
done

# --- 5. retire the previous "Remote Operator" service (files are kept) ---------------------
if systemctl list-unit-files remote-operator.service --no-legend 2>/dev/null | grep -q remote-operator; then
  if systemctl is-active remote-operator >/dev/null 2>&1 || systemctl is-enabled remote-operator >/dev/null 2>&1; then
    log "Disabling the previous 'remote-operator' service (its files are left in place)"
    systemctl disable --now remote-operator >/dev/null 2>&1 || true
  fi
fi
pkill -x go2rtc >/dev/null 2>&1 || true

if [ -n "$REAPPLY_CONN" ]; then
  # Re-activate the pinned wired profile last and detached: the link blips for a moment, which may
  # end an SSH session that runs the installer, but everything is already done by then.
  log "Re-activating '$REAPPLY_CONN' in 3 s (the wired link blips briefly)…"
  setsid nohup sh -c "sleep 3; nmcli connection up '$REAPPLY_CONN'" >/dev/null 2>&1 < /dev/null &
fi
exit 0
