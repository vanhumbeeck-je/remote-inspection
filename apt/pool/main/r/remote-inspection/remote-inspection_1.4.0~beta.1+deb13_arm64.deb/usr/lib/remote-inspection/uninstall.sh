#!/usr/bin/env bash
# Remove the Remote Inspection node.
#
#   sudo bash uninstall.sh [--purge]    remove a source install (--purge also deletes the state/name)
#   uninstall.sh --system-only [--purge]  only the system integration (used by the Debian package,
#                                         whose files dpkg removes itself)
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run as root: sudo bash $0" >&2; exit 1; }
PURGE=0; SYSTEM_ONLY=0
for a in "$@"; do
  case "$a" in
    --purge) PURGE=1 ;;
    --system-only) SYSTEM_ONLY=1 ;;
  esac
done
if [ "$SYSTEM_ONLY" -eq 0 ]; then
  if dpkg-query -W -f='${Status}' remote-inspection 2>/dev/null | grep -q 'install ok installed'; then
    echo "Remote Inspection is installed as a package: remove it with  sudo apt purge remote-inspection" >&2
    exit 1
  fi
  systemctl disable --now inspection-node >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/inspection-node.service
  systemctl daemon-reload
  rm -rf /opt/inspection
fi
# WiFi integration: the hotspot profile, the polkit rule, the captive DNS and the LED rule (saved
# WiFi networks are kept: the Pi stays on its network); the links' no-power-saving settings
command -v nmcli >/dev/null 2>&1 && nmcli connection delete inspection-hotspot >/dev/null 2>&1 || true
rm -f /etc/polkit-1/rules.d/50-inspection-network.rules \
      /etc/NetworkManager/dnsmasq-shared.d/50-inspection-captive.conf /etc/udev/rules.d/90-inspection-led.rules \
      /etc/NetworkManager/conf.d/20-inspection-no-powersave.conf \
      /etc/NetworkManager/dispatcher.d/90-inspection-no-powersave
for led in /sys/class/leds/ACT /sys/class/leds/led0; do
  [ -e "$led/trigger" ] && { echo mmc0 > "$led/trigger"; } 2>/dev/null || true
done
if [ "$PURGE" -eq 1 ]; then
  rm -rf /var/lib/inspection
  userdel inspection >/dev/null 2>&1 || true
  echo "Remote Inspection node removed (including its state)."
else
  echo "Remote Inspection node removed (state kept in /var/lib/inspection; add --purge to delete it)."
fi
