#!/usr/bin/python3
"""Remote Inspection node: starts the compiled service (installed by the remote-inspection package)."""
import sys

from inspection_node.__main__ import main

sys.exit(main())
